#!/usr/bin/env bash
set -Eeuo pipefail

# Encuentra el proyecto desde el repositorio, aunque esté dentro de claro-bb-main/.
WORKSPACE="${GITHUB_WORKSPACE:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
OUTPUT_DIR="${GITHUB_WORKSPACE:-$WORKSPACE}"
BUILD_DIR="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/panther-ios-build"
IPA_NAME="${IPA_NAME:-Panther-iOS-FIRMABLE.ipa}"
LOG_FILE="$OUTPUT_DIR/panther-ios-build.log"

fail() {
  echo "::error::$*" >&2
  exit 1
}

mkdir -p "$BUILD_DIR"
: > "$LOG_FILE"
exec > >(tee -a "$LOG_FILE") 2>&1

command -v xcodebuild >/dev/null 2>&1 || fail "xcodebuild no está disponible; ejecuta este flujo en un runner macOS."
command -v python3 >/dev/null 2>&1 || fail "Python 3 no está disponible en el runner."

PROJECTS=()
while IFS= read -r -d '' item; do PROJECTS+=("$item"); done < <(
  find "$WORKSPACE" -type d -name 'ThreeOneOSFive.xcodeproj' \
    -not -path '*/.git/*' -not -path '*/Build/*' -print0
)

if [[ ${#PROJECTS[@]} -eq 0 ]]; then
  fail "No se encontró ThreeOneOSFive.xcodeproj. Sube el contenido completo de claro-bb-main al repositorio."
fi
if [[ ${#PROJECTS[@]} -gt 1 ]]; then
  printf 'Proyectos encontrados:\n'
  printf ' - %s\n' "${PROJECTS[@]}"
  fail "Hay más de un ThreeOneOSFive.xcodeproj; deja solo el proyecto correcto."
fi

PROJECT="${PROJECTS[0]}"
echo "=============================================="
echo "Panther iOS - diagnóstico y compilación"
echo "Workspace: $WORKSPACE"
echo "Proyecto:  $PROJECT"
xcodebuild -version

if ! xcodebuild -list -json -project "$PROJECT" > "$BUILD_DIR/project-list.json"; then
  fail "Xcode no pudo leer $PROJECT. Revisa que el proyecto esté completo."
fi

SCHEME="$(python3 - "$BUILD_DIR/project-list.json" <<'PY'
import json, sys
with open(sys.argv[1], encoding='utf-8') as f:
    data = json.load(f)
project = data.get('project', {})
schemes = project.get('schemes') or []
if not schemes:
    targets = project.get('targets') or []
    if targets:
        schemes = targets
if not schemes:
    raise SystemExit('No se encontraron schemes ni targets en el proyecto Xcode.')
print('3105' if '3105' in schemes else schemes[0])
PY
)" || fail "No se pudo detectar un scheme/target válido."
echo "Scheme: $SCHEME"

# Resuelve dependencias antes de compilar y deja un mensaje claro si falla.
xcodebuild -resolvePackageDependencies -project "$PROJECT" -scheme "$SCHEME" || \
  fail "Falló la resolución de dependencias Swift Package Manager."

set +e
xcodebuild build \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$BUILD_DIR/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY= \
  | tee -a "$LOG_FILE"
BUILD_STATUS=${PIPESTATUS[0]}
set -e
if [[ "$BUILD_STATUS" -ne 0 ]]; then
  echo "::error::xcodebuild terminó con código $BUILD_STATUS. El log completo se guardará como artefacto."
  exit "$BUILD_STATUS"
fi

PRODUCTS="$BUILD_DIR/DerivedData/Build/Products/Release-iphoneos"
APP="$(find "$PRODUCTS" -maxdepth 1 -type d -name '*.app' -print -quit 2>/dev/null || true)"
[[ -n "$APP" && -d "$APP" ]] || fail "No se encontró la aplicación .app en $PRODUCTS."

STAGING="$BUILD_DIR/ipa-staging"
rm -rf "$STAGING"
mkdir -p "$STAGING/Payload"
ditto "$APP" "$STAGING/Payload/$(basename "$APP")"
rm -f "$OUTPUT_DIR/$IPA_NAME"
(
  cd "$STAGING"
  /usr/bin/zip -qry "$OUTPUT_DIR/$IPA_NAME" Payload
)
/usr/bin/unzip -t "$OUTPUT_DIR/$IPA_NAME" | tail -n 1
echo "IPA creado correctamente: $OUTPUT_DIR/$IPA_NAME"
echo "NOTA: el IPA está SIN FIRMAR. Para instalarlo necesitas firmarlo con un certificado y perfil Apple válidos."
