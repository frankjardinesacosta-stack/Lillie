# Cambios SENSI OG

- El encabezado de marca del login y del menú de patches ahora dice `SENSI OG`.
- El título de alerta del menú y el encabezado visible del panel web también usan `SENSI OG`.
- El icono circular del encabezado del menú usa la imagen del demonio enviada por el usuario.
- El audio `welcome_baby.m4a` ya no se reproduce al cerrar sesión; ahora se reproduce solo después de que la API autorice una key introducida manualmente y la app confirme permisos y vigencia.
- La restauración silenciosa de una key guardada no reproduce el audio.
- Las keys rechazadas muestran `SENSI OG EXTERNAL — key inválida.` en la calculadora; los errores de key vencida o revocada también tienen el prefijo SENSI OG EXTERNAL.
- Se conserva la validación remota existente: sin respuesta válida de la API no se establece el rol ni se permite entrar.
- El menú de patches, el catálogo y sus controles no se rediseñaron.

## Verificación pendiente

Este entorno no dispone de Xcode ni del backend privado de Lovable. No se pudo compilar la IPA ni probar keys reales contra el servidor. La URL configurada en `Info.plist` se conserva sin cambios.
